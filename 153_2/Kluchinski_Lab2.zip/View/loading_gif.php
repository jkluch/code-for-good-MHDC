<div id="loading_container">
	<div id="loading">
		<div id="the_gif"><img src="view/477.gif" /></div>
		<div id="loading_text">Loading...</div>
	</div>
</div>
<script>
    $('#loading_container').css("display", "block");
</script>