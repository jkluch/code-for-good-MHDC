<script>
    $('#tables').hide();
</script>

<div id='tables_container'>
	<div id='tables'>

		<?php
		include 'thinker_table.php';
		include 'ideas_table.php';
		include 'related_table.php';
		?>

	</div>
</div>
