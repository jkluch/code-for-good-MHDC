        <div id="footer">
            <p class="copyright">
            	Thinker Lookup &copy; <?php echo date("Y"); ?>
            </p>
        </div>
    </div><!-- end page -->
    </body>
</html>